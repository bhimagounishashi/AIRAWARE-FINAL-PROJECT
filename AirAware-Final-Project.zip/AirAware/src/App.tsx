import { useEffect, useState, type FormEvent } from 'react'
import { Activity, ArrowRight, Leaf, ShieldCheck, Wind, AlertCircle, Clock3 } from 'lucide-react'
import AqiScale from './components/AqiScale'
import AqiSummary from './components/AqiSummary'
import CitySearch from './components/CitySearch'
import PollutantGrid from './components/PollutantGrid'
import TrendChart from './components/TrendChart'
import { fetchAirQuality, findCity } from './services/airQualityApi'
import type { AirReading, City } from './types/airQuality'
import { validateCityQuery } from './utils/validation'

const DEFAULT_CITY: City = {
  id: 1264527,
  name: 'Hyderabad',
  latitude: 17.385,
  longitude: 78.4867,
  country: 'India',
  admin1: 'Telangana',
}

const RECENT_CITIES_KEY = 'airaware.recent-cities.v1'

function readRecentCities(): City[] {
  try {
    const raw = localStorage.getItem(RECENT_CITIES_KEY)
    if (!raw) return []
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.filter((item): item is City =>
      typeof item === 'object' && item !== null &&
      'name' in item && typeof item.name === 'string' &&
      'latitude' in item && typeof item.latitude === 'number' &&
      'longitude' in item && typeof item.longitude === 'number' &&
      'id' in item && typeof item.id === 'number',
    ).slice(0, 4)
  } catch {
    return []
  }
}

function App() {
  const [city, setCity] = useState<City>(DEFAULT_CITY)
  const [reading, setReading] = useState<AirReading | null>(null)
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [refreshCounter, setRefreshCounter] = useState(0)
  const [recentCities, setRecentCities] = useState<City[]>(readRecentCities)

  useEffect(() => {
    try {
      localStorage.setItem(RECENT_CITIES_KEY, JSON.stringify(recentCities))
    } catch {
      // The dashboard remains usable when browser storage is unavailable.
    }
  }, [recentCities])

  useEffect(() => {
    let active = true
    setLoading(true)
    setError('')
    fetchAirQuality(city)
      .then((result) => {
        if (!active) return
        setReading(result)
        setRecentCities((previous) =>
          [city, ...previous.filter((item) => item.id !== city.id)].slice(0, 4),
        )
      })
      .catch((reason: unknown) => {
        if (!active) return
        setError(reason instanceof Error ? reason.message : 'Unable to load air-quality data.')
      })
      .finally(() => { if (active) setLoading(false) })

    return () => { active = false }
  }, [city, refreshCounter])

  async function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const validationError = validateCityQuery(query)
    if (validationError) {
      setError(validationError)
      return
    }
    setLoading(true)
    setError('')
    try {
      const result = await findCity(query)
      setCity(result)
      setQuery('')
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'City search failed.')
      setLoading(false)
    }
  }

  const observedAt = reading
    ? new Date(reading.observedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })
    : 'Waiting for data'

  return (
    <div className="app-shell">
      <header className="site-header">
        <a className="brand" href="#" aria-label="AirAware home">
          <span className="brand-symbol"><Wind size={21} /></span>
          <span>air<span>aware</span><small>THE AIR QUALITY COMPANION</small></span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#dashboard">Dashboard</a>
          <a href="#aqi-guide">AQI guide</a>
          <a href="#about">About</a>
        </nav>
        <span className="header-status"><i /> LIVE AIR INSIGHTS</span>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow"><span /> BREATHE BETTER. LIVE BETTER.</p>
            <h1>Know the air<br />you <em>breathe.</em></h1>
            <p className="hero-description">
              AirAware turns air-quality data into clear, useful information.
              Check your city, understand pollution levels and plan your day with confidence.
            </p>
            <div className="hero-points">
              <span><Activity size={15} /> City-level AQI</span>
              <span><ShieldCheck size={15} /> Health guidance</span>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="sun" />
            <div className="hill hill-one" />
            <div className="hill hill-two" />
            <div className="hero-caption"><Leaf size={14} /> A clearer view of the air around you</div>
          </div>
        </section>

        <section className="dashboard-section" id="dashboard">
          <div className="section-title-row">
            <div>
              <p className="eyebrow dark">YOUR AIR, AT A GLANCE</p>
              <h2>Air quality dashboard</h2>
            </div>
            <span className="updated-label"><Clock3 size={14} /> {observedAt}</span>
          </div>

          <CitySearch
            city={city}
            query={query}
            loading={loading}
            onQueryChange={setQuery}
            onSearch={handleSearch}
            onRefresh={() => setRefreshCounter((count) => count + 1)}
          />

          {error && <div className="error-banner" role="alert"><AlertCircle size={18} /> {error}</div>}

          <div className="dashboard-grid">
            <AqiSummary reading={reading} loading={loading} />
            <PollutantGrid reading={reading} />
          </div>
          <TrendChart reading={reading} />
          {recentCities.length > 1 && (
            <section className="recent-section" aria-label="Recently viewed cities">
              <h3>Recently checked</h3>
              <div className="recent-list">
                {recentCities.filter((item) => item.id !== city.id).map((item) => (
                  <button type="button" key={item.id} onClick={() => setCity(item)}>
                    <span>{item.name}</span><small>{item.country ?? item.admin1 ?? 'View city'}</small><ArrowRight size={15} />
                  </button>
                ))}
              </div>
            </section>
          )}
        </section>

        <AqiScale />

        <section className="about-section" id="about">
          <div className="about-icon"><Leaf size={25} /></div>
          <div>
            <p className="eyebrow">A LITTLE MORE AWARENESS</p>
            <h2>Better information. Healthier everyday choices.</h2>
            <p>Check the AQI before outdoor activities. When air quality is poor, consider reducing strenuous outdoor exercise, keeping windows closed when appropriate, and following local public-health advice.</p>
          </div>
        </section>
      </main>

      <footer>
        <a className="footer-brand" href="#"><Wind size={17} /> airaware</a>
        <span>Educational project · Air-quality data by Open-Meteo</span>
        <a href="https://open-meteo.com/en/docs/air-quality-api" target="_blank" rel="noreferrer">API documentation ↗</a>
      </footer>
    </div>
  )
}

export default App
