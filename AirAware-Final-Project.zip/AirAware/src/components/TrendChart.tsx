import { useState } from 'react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import type { AirReading } from '../types/airQuality'

type Props = { reading: AirReading | null }

export default function TrendChart({ reading }: Props) {
  const [metric, setMetric] = useState<'aqi' | 'pm25'>('aqi')
  const data = reading?.hourly ?? []

  return (
    <article className="panel chart-panel">
      <div className="chart-heading">
        <div>
          <span className="panel-label">HOURLY OUTLOOK</span>
          <h3>How the air changes</h3>
          <p>Hourly model forecast for {reading?.city.name ?? 'your selected city'}</p>
        </div>
        <div className="chart-switch" role="group" aria-label="Choose chart metric">
          <button className={metric === 'aqi' ? 'selected' : ''} onClick={() => setMetric('aqi')} type="button">AQI</button>
          <button className={metric === 'pm25' ? 'selected' : ''} onClick={() => setMetric('pm25')} type="button">PM2.5</button>
        </div>
      </div>
      {data.length ? (
        <div className="chart-area">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 12, right: 8, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38b98b" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#38b98b" stopOpacity={0.015} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#edf2ef" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: '#87958e', fontSize: 10 }} axisLine={false} tickLine={false} interval={3} />
              <YAxis tick={{ fill: '#87958e', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ border: '1px solid #e6eee9', borderRadius: 10, fontSize: 12 }}
                formatter={(value: number) => [metric === 'aqi' ? `${value} AQI` : `${value} μg/m³`, metric === 'aqi' ? 'US AQI' : 'PM2.5']}
              />
              <Area type="monotone" dataKey={metric} stroke="#35b487" strokeWidth={2.5} fill="url(#trendFill)" activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="chart-empty">Hourly trend data is not available yet.</div>
      )}
      <div className="chart-footer">Forecast values are estimates and may change as the model updates.</div>
    </article>
  )
}
