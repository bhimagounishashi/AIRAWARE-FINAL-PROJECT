import { Search, MapPin, RefreshCw } from 'lucide-react'
import type { FormEvent } from 'react'
import type { City } from '../types/airQuality'

type Props = {
  city: City
  query: string
  loading: boolean
  onQueryChange: (value: string) => void
  onSearch: (event: FormEvent<HTMLFormElement>) => void
  onRefresh: () => void
}

export default function CitySearch({ city, query, loading, onQueryChange, onSearch, onRefresh }: Props) {
  return (
    <div className="toolbar">
      <div className="selected-city">
        <MapPin size={18} aria-hidden="true" />
        <div>
          <strong>{city.name}</strong>
          <span>{[city.admin1, city.country].filter(Boolean).join(', ')}</span>
        </div>
      </div>
      <form className="search-form" onSubmit={onSearch}>
        <Search size={17} aria-hidden="true" />
        <label className="sr-only" htmlFor="city-search">Search a city</label>
        <input
          id="city-search"
          value={query}
          onChange={(event) => onQueryChange(event.target.value)}
          placeholder="Search another city..."
          maxLength={60}
          autoComplete="off"
        />
        <button type="submit" disabled={loading}>Search</button>
      </form>
      <button className="icon-button" type="button" onClick={onRefresh} disabled={loading} aria-label="Refresh current city data">
        <RefreshCw size={17} className={loading ? 'spin' : ''} />
      </button>
    </div>
  )
}
