import { AQI_LEVELS } from '../utils/aqi'

export default function AqiScale() {
  return (
    <section className="scale-section" id="aqi-guide" aria-labelledby="scale-title">
      <div className="section-intro">
        <p className="eyebrow">THE QUICK GUIDE</p>
        <h2 id="scale-title">Understand the <em>AQI scale.</em></h2>
        <p className="section-description">
          The US Air Quality Index is a colour-coded scale from 0 to 500.
          A higher number means greater potential health concern.
        </p>
      </div>
      <div className="scale-grid">
        {AQI_LEVELS.map((level) => (
          <article className="scale-item" key={level.key}>
            <span className="scale-swatch" style={{ backgroundColor: level.color }} />
            <div className="scale-item-content">
              <div className="scale-item-heading">
                <strong>{level.label}</strong>
                <span>{level.min}–{level.max}</span>
              </div>
              <p>{level.advice}</p>
            </div>
          </article>
        ))}
      </div>
      <p className="scale-footnote">AQI category descriptions are general guidance, not a medical diagnosis.</p>
    </section>
  )
}
