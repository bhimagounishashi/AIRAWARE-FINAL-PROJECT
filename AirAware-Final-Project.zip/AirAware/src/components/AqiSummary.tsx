import { Activity, HeartPulse } from 'lucide-react'
import type { AirReading } from '../types/airQuality'
import { getAqiLevel } from '../utils/aqi'

type Props = { reading: AirReading | null; loading: boolean }

export default function AqiSummary({ reading, loading }: Props) {
  const level = getAqiLevel(reading?.aqi ?? 0)
  const value = reading?.aqi
  const percentage = value === undefined ? 0 : Math.min(100, (value / 500) * 100)

  return (
    <article className="panel aqi-panel">
      <div className="panel-top">
        <span className="panel-label">CURRENT AIR QUALITY</span>
        <span className="live-tag"><i /> LIVE</span>
      </div>
      <div className="aqi-value-row">
        <div>
          <div className="aqi-value">{loading && !reading ? '—' : value ?? '—'}</div>
          <span className="aqi-unit">US AQI · OUT OF 500</span>
        </div>
        <span className="aqi-badge" style={{ color: level.color, backgroundColor: level.background }}>
          <i style={{ backgroundColor: level.color }} />
          {loading && !reading ? 'Loading' : level.label}
        </span>
      </div>
      <div className="aqi-track" aria-label={`AQI scale position: ${value ?? 0} out of 500`}>
        <span style={{ width: `${percentage}%`, backgroundColor: level.color }} />
      </div>
      <div className="track-labels"><span>0 · Clean</span><span>500 · Hazardous</span></div>
      <div className="health-note">
        <HeartPulse size={18} />
        <p>{loading && !reading ? 'Fetching the latest reading...' : level.advice}</p>
      </div>
      <div className="panel-footer"><span><Activity size={14} /> Air quality index</span><span>US AQI standard</span></div>
    </article>
  )
}
