import { Wind } from 'lucide-react'
import type { AirReading } from '../types/airQuality'

type Props = { reading: AirReading | null }

const pollutantInfo = [
  { key: 'pm25', label: 'PM2.5', description: 'Fine particles', unit: 'μg/m³' },
  { key: 'pm10', label: 'PM10', description: 'Coarse particles', unit: 'μg/m³' },
  { key: 'ozone', label: 'Ozone', description: 'Ground-level O₃', unit: 'μg/m³' },
  { key: 'nitrogenDioxide', label: 'Nitrogen dioxide', description: 'Traffic-related NO₂', unit: 'μg/m³' },
] as const

export default function PollutantGrid({ reading }: Props) {
  return (
    <article className="panel pollutant-panel">
      <div className="panel-top">
        <span className="panel-label">POLLUTANT SNAPSHOT</span>
        <span className="panel-icon"><Wind size={17} /></span>
      </div>
      <div className="pollutant-grid">
        {pollutantInfo.map((item) => {
          const value = reading?.[item.key]
          return (
            <div className="pollutant" key={item.key}>
              <span className="pollutant-name">{item.label}</span>
              <strong>{value === undefined ? '—' : value}<small> {item.unit}</small></strong>
              <span className="pollutant-description">{item.description}</span>
            </div>
          )
        })}
      </div>
      <p className="pollutant-note">Pollutant values are reported by the selected air-quality data model.</p>
    </article>
  )
}
