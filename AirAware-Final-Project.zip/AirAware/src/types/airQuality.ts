export interface City {
  id: number
  name: string
  latitude: number
  longitude: number
  country?: string
  admin1?: string
}

export interface GeocodingResponse {
  results?: City[]
}

export interface CurrentAirQuality {
  time: string
  us_aqi?: number
  pm2_5?: number
  pm10?: number
  ozone?: number
  nitrogen_dioxide?: number
  sulphur_dioxide?: number
  carbon_monoxide?: number
}

export interface HourlyAirQuality {
  time: string[]
  us_aqi?: number[]
  pm2_5?: number[]
}

export interface AirQualityResponse {
  current?: CurrentAirQuality
  hourly?: HourlyAirQuality
  timezone?: string
}

export interface HourlyPoint {
  time: string
  label: string
  aqi: number
  pm25: number
}

export interface AirReading {
  city: City
  aqi: number
  pm25: number
  pm10: number
  ozone: number
  nitrogenDioxide: number
  sulphurDioxide: number
  carbonMonoxide: number
  observedAt: string
  hourly: HourlyPoint[]
}
