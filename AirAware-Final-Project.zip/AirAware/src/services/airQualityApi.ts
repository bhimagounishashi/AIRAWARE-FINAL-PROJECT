import type {
  AirQualityResponse,
  AirReading,
  City,
  GeocodingResponse,
  HourlyPoint,
} from '../types/airQuality'
import { clampAqi } from '../utils/aqi'
import { normalizeCityQuery, validateCityQuery } from '../utils/validation'

const GEOCODING_ENDPOINT = 'https://geocoding-api.open-meteo.com/v1/search'
const AIR_QUALITY_ENDPOINT = 'https://air-quality-api.open-meteo.com/v1/air-quality'
const REQUEST_TIMEOUT_MS = 12_000

async function fetchJson<T>(url: URL): Promise<T> {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    })
    if (!response.ok) {
      throw new Error(`The data service returned an error (${response.status}). Please try again.`)
    }
    return (await response.json()) as T
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new Error('The request took too long. Check your connection and try again.')
    }
    if (error instanceof TypeError) {
      throw new Error('Could not connect to the data service. Check your internet connection.')
    }
    throw error
  } finally {
    window.clearTimeout(timeout)
  }
}

export async function findCity(input: string): Promise<City> {
  const validationError = validateCityQuery(input)
  if (validationError) throw new Error(validationError)

  const url = new URL(GEOCODING_ENDPOINT)
  url.search = new URLSearchParams({
    name: normalizeCityQuery(input),
    count: '8',
    language: 'en',
    format: 'json',
  }).toString()

  const data = await fetchJson<GeocodingResponse>(url)
  const city = data.results?.[0]
  if (!city) throw new Error(`No matching city found for "${normalizeCityQuery(input)}". Try a nearby major city.`)
  return city
}

function toHourlyPoints(data: AirQualityResponse): HourlyPoint[] {
  const times = data.hourly?.time ?? []
  const aqiValues = data.hourly?.us_aqi ?? []
  const pmValues = data.hourly?.pm2_5 ?? []

  return times.slice(0, 24).map((time, index) => {
    const date = new Date(time)
    return {
      time,
      label: Number.isNaN(date.getTime())
        ? time
        : date.toLocaleTimeString([], { hour: 'numeric' }),
      aqi: clampAqi(aqiValues[index] ?? 0),
      pm25: Number((pmValues[index] ?? 0).toFixed(1)),
    }
  })
}

export async function fetchAirQuality(city: City): Promise<AirReading> {
  const url = new URL(AIR_QUALITY_ENDPOINT)
  url.search = new URLSearchParams({
    latitude: String(city.latitude),
    longitude: String(city.longitude),
    current: 'us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide,sulphur_dioxide,carbon_monoxide',
    hourly: 'us_aqi,pm2_5',
    forecast_days: '1',
    timezone: 'auto',
  }).toString()

  const data = await fetchJson<AirQualityResponse>(url)
  if (!data.current || typeof data.current.us_aqi !== 'number') {
    throw new Error('The service did not return a current AQI reading for this city.')
  }

  const current = data.current
  return {
    city,
    aqi: clampAqi(current.us_aqi),
    pm25: Number((current.pm2_5 ?? 0).toFixed(1)),
    pm10: Number((current.pm10 ?? 0).toFixed(1)),
    ozone: Number((current.ozone ?? 0).toFixed(1)),
    nitrogenDioxide: Number((current.nitrogen_dioxide ?? 0).toFixed(1)),
    sulphurDioxide: Number((current.sulphur_dioxide ?? 0).toFixed(1)),
    carbonMonoxide: Number((current.carbon_monoxide ?? 0).toFixed(1)),
    observedAt: current.time,
    hourly: toHourlyPoints(data),
  }
}
