import { describe, expect, it } from 'vitest'
import { normalizeCityQuery, validateCityQuery } from './validation'

describe('city query validation', () => {
  it('normalizes whitespace', () => {
    expect(normalizeCityQuery('  New   Delhi  ')).toBe('New Delhi')
  })

  it('rejects empty and too-short input', () => {
    expect(validateCityQuery('  ')).toBe('Enter a city name to search.')
    expect(validateCityQuery('A')).toBe('Enter at least 2 characters.')
  })

  it('rejects unsupported characters and long input', () => {
    expect(validateCityQuery('City123')).toContain('Use letters')
    expect(validateCityQuery('x'.repeat(61))).toContain('60 characters')
  })

  it('accepts city names with spaces and punctuation', () => {
    expect(validateCityQuery("St. John's")).toBeNull()
    expect(validateCityQuery('Hyderabad')).toBeNull()
  })
})
