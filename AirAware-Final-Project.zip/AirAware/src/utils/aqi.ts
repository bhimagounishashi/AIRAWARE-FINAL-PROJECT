export type AqiLevel = {
  key: string
  label: string
  min: number
  max: number
  color: string
  background: string
  advice: string
  sensitiveAdvice: string
}

export const AQI_LEVELS: AqiLevel[] = [
  {
    key: 'good', label: 'Good', min: 0, max: 50, color: '#229b70', background: '#e5f7ef',
    advice: 'Air quality is satisfactory. Enjoy outdoor activities.',
    sensitiveAdvice: 'No special precautions are generally needed.',
  },
  {
    key: 'moderate', label: 'Moderate', min: 51, max: 100, color: '#b17b13', background: '#fff4d8',
    advice: 'Air quality is acceptable for most people.',
    sensitiveAdvice: 'Unusually sensitive people may consider reducing prolonged outdoor exertion.',
  },
  {
    key: 'sensitive', label: 'Unhealthy for sensitive groups', min: 101, max: 150, color: '#c66a28', background: '#fff0e4',
    advice: 'Some people may begin to experience health effects.',
    sensitiveAdvice: 'Children, older adults and people with heart or lung conditions should reduce prolonged outdoor exertion.',
  },
  {
    key: 'unhealthy', label: 'Unhealthy', min: 151, max: 200, color: '#c83f50', background: '#ffeaed',
    advice: 'Health effects may be experienced by everyone.',
    sensitiveAdvice: 'Sensitive groups should avoid prolonged outdoor exertion; everyone else should reduce it.',
  },
  {
    key: 'very-unhealthy', label: 'Very unhealthy', min: 201, max: 300, color: '#8155b7', background: '#f1eafd',
    advice: 'Health alert: the risk of health effects is increased for everyone.',
    sensitiveAdvice: 'Avoid prolonged outdoor exertion and follow local health guidance.',
  },
  {
    key: 'hazardous', label: 'Hazardous', min: 301, max: 500, color: '#8c4030', background: '#f7e8e3',
    advice: 'Health warning of emergency conditions.',
    sensitiveAdvice: 'Avoid outdoor activity where possible and follow local authority guidance.',
  },
]

export function getAqiLevel(value: number): AqiLevel {
  const safeValue = Number.isFinite(value) ? Math.max(0, value) : 0
  return AQI_LEVELS.find((level) => safeValue <= level.max) ?? AQI_LEVELS[AQI_LEVELS.length - 1]
}

export function clampAqi(value: number): number {
  if (!Number.isFinite(value)) return 0
  return Math.min(500, Math.max(0, Math.round(value)))
}
