export function normalizeCityQuery(value: string): string {
  return value.trim().replace(/\s+/g, ' ')
}

export function validateCityQuery(value: string): string | null {
  const query = normalizeCityQuery(value)
  if (!query) return 'Enter a city name to search.'
  if (query.length < 2) return 'Enter at least 2 characters.'
  if (query.length > 60) return 'City name must be 60 characters or fewer.'
  if (!/^[\p{L}\p{M} .'-]+$/u.test(query)) return 'Use letters, spaces, apostrophes, periods or hyphens only.'
  return null
}
