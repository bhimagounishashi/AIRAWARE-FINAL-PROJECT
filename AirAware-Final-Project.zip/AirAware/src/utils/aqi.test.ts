import { describe, expect, it } from 'vitest'
import { clampAqi, getAqiLevel } from './aqi'

describe('getAqiLevel', () => {
  it.each([
    [0, 'Good'],
    [50, 'Good'],
    [51, 'Moderate'],
    [100, 'Moderate'],
    [101, 'Unhealthy for sensitive groups'],
    [151, 'Unhealthy'],
    [201, 'Very unhealthy'],
    [301, 'Hazardous'],
    [500, 'Hazardous'],
  ])('classifies AQI %i correctly', (value, expected) => {
    expect(getAqiLevel(value).label).toBe(expected)
  })
})

describe('clampAqi', () => {
  it('keeps values inside the US AQI range', () => {
    expect(clampAqi(-10)).toBe(0)
    expect(clampAqi(520)).toBe(500)
    expect(clampAqi(42.6)).toBe(43)
  })

  it('returns zero for non-finite values', () => {
    expect(clampAqi(Number.NaN)).toBe(0)
  })
})
