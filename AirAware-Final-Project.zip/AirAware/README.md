# AirAware — Air Quality Dashboard

AirAware is an Agriculture, Environment & Smart City project. It explains the Air Quality Index (AQI) in a static learning page and provides a city-based air-quality dashboard in the dynamic React application.

## Requirements mapped to implementation

| Brief requirement | Where it is implemented |
|---|---|
| Static AQI scale explainer | `static-phase/index.html` |
| HTML and CSS | `static-phase/index.html`, `static-phase/style.css` |
| CSS Grid | `.aqi-grid` and `.tips-grid` in `static-phase/style.css` |
| Mobile-first media queries | `static-phase/style.css` and `src/styles.css` |
| Dynamic city AQI using API | `src/services/airQualityApi.ts` |
| Colour-coded cards | `src/components/AqiSummary.tsx`, `src/components/AqiScale.tsx` |
| Trend chart | `src/components/TrendChart.tsx` |
| TypeScript typed data | `src/types/airQuality.ts` |
| Fetch API | `fetchJson`, `findCity`, `fetchAirQuality` in `src/services/airQualityApi.ts` |
| React components and state | `src/App.tsx` and `src/components/` |

## Project structure

```text
AirAware/
├── index.html                 # React app entry
├── static-phase/
│   ├── index.html             # Standalone HTML/CSS AQI explainer
│   └── style.css
├── src/
│   ├── components/
│   │   ├── AqiScale.tsx
│   │   ├── AqiSummary.tsx
│   │   ├── CitySearch.tsx
│   │   ├── PollutantGrid.tsx
│   │   └── TrendChart.tsx
│   ├── services/airQualityApi.ts
│   ├── types/airQuality.ts
│   ├── utils/
│   │   ├── aqi.ts
│   │   └── validation.ts
│   ├── test/setup.ts
│   ├── utils/aqi.test.ts
│   ├── utils/validation.test.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── styles.css
├── package.json
├── tsconfig*.json
├── vite.config.ts
└── vitest.config.ts
```

## Run the project

Requirements: Node.js 18 or newer and npm.

```bash
npm install
npm run dev
```

Open the local address printed by Vite, usually `http://localhost:5173`.

To build and test:

```bash
npm run build
npm test
npm run preview
```

## Static phase

The static phase is a separate page and does not depend on React or an API. After starting Vite, open:

`http://localhost:5173/static-phase/`

It includes six AQI bands, short descriptions, a practical tips section, CSS Grid and mobile-first breakpoints.

## Dynamic phase

The main page starts with Hyderabad, Telangana. Search for another city to retrieve its coordinates from Open-Meteo Geocoding and then request current and hourly air-quality data.

- Current US AQI
- PM2.5, PM10, ozone and nitrogen dioxide readings
- Colour-coded AQI category and general health advice
- Hourly AQI / PM2.5 trend chart
- Refresh action
- Recently checked cities stored locally in the browser
- Input validation, loading state, error feedback and request timeout

## API endpoints

- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- Air quality: `https://air-quality-api.open-meteo.com/v1/air-quality`
- Documentation: https://open-meteo.com/en/docs/air-quality-api

No API key is required for this educational demonstration. Internet access is required for live data.

## Design and reliability notes

- API requests use `URL` and `URLSearchParams`, rather than concatenating untrusted input into a URL.
- City input is trimmed, length-limited and validated.
- Requests have a 12-second timeout and display useful errors.
- React effects ignore stale responses after unmount or city changes.
- Browser storage is treated as optional and parsed defensively.
- API response fields are represented with TypeScript interfaces.
- Components separate the city search, AQI summary, pollutant metrics, chart and static AQI guide.

## AQI bands used

This educational page uses common US AQI categories: Good (0–50), Moderate (51–100), Unhealthy for Sensitive Groups (101–150), Unhealthy (151–200), Very Unhealthy (201–300), and Hazardous (301–500).

## Limitations

Open-Meteo air-quality values are model estimates and may differ from readings at local regulatory monitoring stations. The app is an educational information tool, not a medical diagnosis or emergency alert service.
